## Important Information (Python Django + React)

This guide has been made from personal projects. The versions used have been chosen and tested against each other to avoid future compatibility failures.

This project has been created for a test for the company company "Connecting Visions - Snippet".

### Docker

To run docker successfully, you need to enter the following commands in the console:
```bash
docker-compose build
docker-compose up
```